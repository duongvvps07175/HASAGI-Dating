<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class requests extends Model
{
    protected $table = 'requests';

}
