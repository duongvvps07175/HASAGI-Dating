<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\users;
use Carbon\Carbon;
use App\images;
use App\likes;
use App\connect;
use App\mess;
use App\requests;
class MyController extends Controller
{
    //
    function show_users(){
    	$results = users::all();
    	$dt = Carbon::now('Asia/Ho_Chi_Minh');
    	return view('/admin/users',['kq'=>$results,'dt'=>$dt]);
    }

    function delUser($id){
        users::where('id',$id)->delete();
        return redirect('admin/users');
    }

    function show_images(){
        $results = images::all();
        $kq  = users::all();
        $kq2 = mess::all();
        return view('/admin/images',['ketqua'=>$results,'kq1'=>$kq,'kq2'=>$kq2]);
    }

    function delImg($id){
         images::where('id',$id)->delete();
        return redirect('admin/images');
    }

    function show_likes(){
        $results = likes::all();
        $kq  = users::all();
        return view('/admin/likes',['ketqua'=>$results,'kq1'=>$kq]);
    }

    function show_connect(){
        $results = connect::all();
        $kq  = users::all();
        return view('/admin/connect',['ketqua'=>$results,'kq1'=>$kq]);
    }
    function add_connect(){
        $ketnoi = connect::all();
        $results = likes::all();
        if(count($ketnoi) != 0){
            for($i = 0; $i < count($results); $i++ ){
                for($j = 1; $i < $j && $j < count($results); $j++){
                    if($results[$i]->id_user == $results[$j]->user_like && $results[$i]->user_like == $results[$j]->id_user){
                        $adc = $results[$i]->id_user;
                        $apc = $results[$i]->user_like;
                        foreach($ketnoi as $kq){
                                if($kq->id_user != $adc && $kq->object != $apc){
                                   $connect = new connect();
                                    $connect->id_user = $adc;
                                    $connect->object = $apc;
                                    $connect->save();
                                }elseif(count($ketnoi) >= count($results)){
                                    return redirect('/admin/Addconnect');
                                }
                            }
                    }else{
                        return redirect('/admin/Addconnect');
                    }
                }
            }
        }else{
            for($i = 0; $i < count($results); $i++ ){
                for($j = 1; $i < $j && $j < count($results); $j++){
                    if($results[$i]->id_user == $results[$j]->user_like && $results[$i]->user_like == $results[$j]->id_user){
                        $adc = $results[$i]->id_user;
                        $apc = $results[$i]->user_like;
                        $connect = new connect();
                        $connect->id_user = $adc;
                        $connect->object = $apc;
                        $connect->save();
                         return redirect('/admin/connect');
                     }
                 }
             }
        }
        return redirect('/admin/Addconnect');
    }  

    function delConnect($id){
         connect::where('id',$id)->delete();
        return redirect('admin/connect');
    }
    function show_mess(){
        $results = mess::all();
        $kq2  = connect::all();
        $kq1 = users::all();
        $kq3 = likes::all();
        return view('/admin/mess',['ketqua'=>$results,'kq1'=>$kq1,'kq2'=>$kq2,'kq3'=>$kq3]);
    }
     function delMess($id){
         mess::where('id_mess',$id)->delete();
        return redirect('/admin/mess');
    }
        function show_request(){
        $results = requests::all();
        $kq1 = users::all();
        return view('/admin/request',['ketqua'=>$results,'kq1'=>$kq1]);
    }
     function delRequest($id){
         requests::where('id',$id)->delete();
        return redirect('/admin/request');
    }
}
