@extends('admin/master')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
                <h4 class="card-id_ch">Yêu Cầu</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
						<th>ID Yêu Cầu</th>
						<th>Người Dùng</th>
						<th>Tuổi Nhỏ Nhất</th>
						<th>Tuổi Lớn Nhất</th>
						<th>Khoảng Cách Tối Đa</th>
						<th>Giới Tính</th>
						<th>Xóa</th>
                    </thead>
                    <tbody>
                    @forelse($ketqua as $kq)
					<tr>
						<td width="100">
							{{$kq->id}}
						</td>
						<td width="100">
							@forelse($kq1 as $kq2)
								@if($kq->id_user === $kq2->id)
								{{$kq2->id}}-{{$kq2->name}}
								@endif
							@empty
							nothing
							@endforelse
						</td>
						<td width="100">
								{{$kq->min_age}}
						</td>
						<td width="100">
							{{$kq->max_age}}
						</td>
						<td width="100">
							{{$kq->max_range}}KM
						</td>
						<td width="100">
							@if($kq->gender == 0)
								Nam
							@elseif($kq->gender == 1)
								Nữ
							@elseif($kq->gender == 2)
								Khác
							@else
								Tất Cả
							@endif
						</td>
						<td width="100">
							<a class="btn btn-danger btn-sm" href="/admin/delRequest/{{$kq->id}}"><span aria-hidden="true">&times;</span></a>
						</td>
					</tr>
					@empty
						không có danh sách
						@endforelse
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
@endsection

