<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/admin', function () {
    return view('admin/home');
});
Route::get('/admin/users','MyController@show_users');
Route::get('admin/deleteUser/{id}', 'MyController@delUser');
Route::get('/admin/images','MyController@show_images');
Route::get('/admin/deleteImg/{id}','MyController@delImg');
Route::get('/admin/likes','MyController@show_likes');
Route::get('/admin/deleteLikes/{id}','MyController@delLikes');
Route::get('/admin/connect','MyController@add_connect');
Route::get('/admin/Addconnect','MyController@show_connect');
Route::get('/admin/delConnect/{id}','MyController@delConnect');
Route::get('/admin/mess','MyController@show_mess');
Route::get('/admin/delMess/{id}','MyController@delMess');
Route::get('/admin/request','MyController@show_request');
Route::get('/admin/delRequest/{id}','MyController@delRequest');

