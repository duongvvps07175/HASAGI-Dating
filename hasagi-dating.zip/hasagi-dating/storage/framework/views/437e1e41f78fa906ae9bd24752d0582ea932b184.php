<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
	                <h4 style="text-align:center">
	                <p>Welcom to Hasagi Dating</p>
	            	</h4>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hasagi-dating\resources\views/admin/home.blade.php ENDPATH**/ ?>