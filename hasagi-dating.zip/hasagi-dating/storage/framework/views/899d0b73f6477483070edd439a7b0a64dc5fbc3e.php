<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
                <h4 class="card-id_ch">Kết Nối</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
						<th>ID Kết Nối</th>
						<th>Người Like</th>
						<th>Người Được Like</th>
						<th>Xóa</th>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $ketqua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td width="100">
							<?php echo e($kq->id); ?>

						</td>
						<td width="100">
							<?php $__empty_2 = true; $__currentLoopData = $kq1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
								<?php if($kq->id_user === $kq2->id): ?>
								<?php echo e($kq2->id); ?>-<?php echo e($kq2->name); ?>

								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
							nothing
							<?php endif; ?>
						</td>
						<td width="100">
							<?php $__empty_2 = true; $__currentLoopData = $kq1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
								<?php if($kq->object === $kq2->id): ?>
								<?php echo e($kq2->id); ?>-<?php echo e($kq2->name); ?>

								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
							nothing
							<?php endif; ?>
						</td>
						<td width="100">
							<a class="btn btn-danger btn-sm" href="/admin/delConnect/<?php echo e($kq->id); ?>"><span aria-hidden="true">&times;</span></a>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						không có danh sách
						<?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hasagi-dating\resources\views/admin/connect.blade.php ENDPATH**/ ?>