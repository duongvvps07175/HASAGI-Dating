<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="#" class="simple-text logo-mini">
          <div class="logo-image-small">
            <img src="<?php echo e(asset('')); ?>assets/img/logo-small.png">
          </div>
        </a>
        <a href="/" class="simple-text logo-normal">
            Hasagi
          <!-- <div class="logo-image-big">
            <img src="assets/img/logo-big.png">
          </div> -->
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="<?php echo e(Request::is('admin') ? 'active' : null); ?>">
            <a href="/admin">
              <i class="nc-icon nc-bank"></i>
              <p>Trang Chủ</p>
            </a>
          </li>
          <li class="<?php echo e(Request::is('admin/users') ? 'active' : null); ?>">
            <a href="/admin/users">
              <i class="nc-icon nc-bank"></i>
              <p>Người Dùng</p>
            </a>
          </li>
          <li class="<?php echo e(Request::is('admin/mess') ? 'active' : null); ?>">
            <a href="/admin/mess">
              <i class="nc-icon nc-tile-56"></i>
              <p>Tin Nhắn</p>
            </a>
          </li>
          <li class="<?php echo e(Request::is('admin/images') ? 'active' : null); ?>">
            <a href="/admin/images">
              <i class="nc-icon nc-tile-56"></i>
              <p>Hình Ảnh</p>
            </a>
          </li>
          <li class="<?php echo e(Request::is('admin/likes') ? 'active' : null); ?>">
            <a href="/admin/likes">
              <i class="nc-icon nc-tile-56"></i>
              <p>Lượt Like</p>
            </a>
          </li>
          <li class="<?php echo e(Request::is('admin/connect') ? 'active' : null); ?>">
            <a href="/admin/connect">
              <i class="nc-icon nc-tile-56"></i>
              <p>Kết Nối</p>
            </a>
          </li>
          <li class="<?php echo e(Request::is('admin/request') ? 'active' : null); ?>">
            <a href="/admin/request">
              <i class="nc-icon nc-tile-56"></i>
              <p>Yêu Cầu</p>
            </a>
          </li>
          <li class="active-pro">
              <button class="btn btn-light btn-sm" name="logout" >
                 <a href="/admin/logout" style="color:white"><i style="color:white" class='fa fa-sign-out'></i>Log Out</a></button>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->

<?php /**PATH C:\laragon\www\hasagi-dating\resources\views/admin/header.blade.php ENDPATH**/ ?>