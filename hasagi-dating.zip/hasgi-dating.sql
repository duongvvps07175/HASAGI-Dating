-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.5.0.5332
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for hasagi-dating
DROP DATABASE IF EXISTS `hasagi-dating`;
CREATE DATABASE IF NOT EXISTS `hasagi-dating` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `hasagi-dating`;

-- Dumping structure for table hasagi-dating.connect
DROP TABLE IF EXISTS `connect`;
CREATE TABLE IF NOT EXISTS `connect` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint(20) unsigned NOT NULL,
  `object` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_connect_likes` (`id_user`),
  KEY `FK_connect_likes_2` (`object`),
  CONSTRAINT `FK_connect_likes` FOREIGN KEY (`id_user`) REFERENCES `likes` (`id_user`),
  CONSTRAINT `FK_connect_likes_2` FOREIGN KEY (`object`) REFERENCES `likes` (`user_like`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table hasagi-dating.connect: ~2 rows (approximately)
/*!40000 ALTER TABLE `connect` DISABLE KEYS */;
REPLACE INTO `connect` (`id`, `id_user`, `object`, `created_at`, `updated_at`) VALUES
	(1, 3, 1, '2019-10-13 19:21:24', '2019-10-13 19:21:24'),
	(2, 2, 1, NULL, NULL);
/*!40000 ALTER TABLE `connect` ENABLE KEYS */;

-- Dumping structure for table hasagi-dating.failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hasagi-dating.failed_jobs: ~0 rows (approximately)
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Dumping structure for table hasagi-dating.images
DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `images_url` varchar(255) NOT NULL,
  `id_user` bigint(20) unsigned DEFAULT NULL,
  `id_mess` bigint(20) unsigned DEFAULT NULL,
  `type` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_images_users` (`id_user`),
  KEY `FK_images_tinnhan` (`id_mess`),
  CONSTRAINT `FK_images_tinnhan` FOREIGN KEY (`id_mess`) REFERENCES `mess` (`id_mess`),
  CONSTRAINT `FK_images_users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table hasagi-dating.images: ~0 rows (approximately)
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
REPLACE INTO `images` (`id`, `images_url`, `id_user`, `id_mess`, `type`) VALUES
	(1, 'abc/xyz', 3, NULL, b'0'),
	(2, 'xyz/abc', NULL, 1, b'1');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;

-- Dumping structure for table hasagi-dating.likes
DROP TABLE IF EXISTS `likes`;
CREATE TABLE IF NOT EXISTS `likes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` bigint(20) unsigned NOT NULL,
  `user_like` bigint(20) unsigned NOT NULL,
  `luotlike` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `FK_likes_users` (`id_user`),
  KEY `FK_likes_users_2` (`user_like`),
  CONSTRAINT `FK_likes_users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`),
  CONSTRAINT `FK_likes_users_2` FOREIGN KEY (`user_like`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table hasagi-dating.likes: ~4 rows (approximately)
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
REPLACE INTO `likes` (`id`, `id_user`, `user_like`, `luotlike`) VALUES
	(1, 3, 1, 1),
	(2, 1, 3, 1),
	(3, 2, 1, 1),
	(4, 1, 2, 1);
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;

-- Dumping structure for table hasagi-dating.mess
DROP TABLE IF EXISTS `mess`;
CREATE TABLE IF NOT EXISTS `mess` (
  `id_mess` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `noidung` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_connect` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_mess`),
  KEY `FK_tinnhan_connect` (`id_connect`),
  CONSTRAINT `FK_tinnhan_connect` FOREIGN KEY (`id_connect`) REFERENCES `connect` (`id`) ON DELETE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hasagi-dating.mess: ~2 rows (approximately)
/*!40000 ALTER TABLE `mess` DISABLE KEYS */;
REPLACE INTO `mess` (`id_mess`, `noidung`, `id_connect`, `created_at`, `updated_at`) VALUES
	(1, 'gfdgdfg gfdgfdgfd fdgdfg', 2, '2019-10-15 15:12:41', '2019-10-15 15:12:44'),
	(2, 'gfdgre ưaass', 1, '2019-10-15 15:12:43', '2019-10-15 15:12:46');
/*!40000 ALTER TABLE `mess` ENABLE KEYS */;

-- Dumping structure for table hasagi-dating.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hasagi-dating.migrations: ~4 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
REPLACE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_10_12_152043_create_tinnhan_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table hasagi-dating.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hasagi-dating.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table hasagi-dating.requests
DROP TABLE IF EXISTS `requests`;
CREATE TABLE IF NOT EXISTS `requests` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id_user` bigint(20) unsigned NOT NULL,
  `min_age` int(2) NOT NULL DEFAULT '18',
  `max_age` int(2) NOT NULL DEFAULT '45',
  `max_range` int(5) NOT NULL DEFAULT '1000',
  `gender` tinyint(4) NOT NULL DEFAULT '3',
  PRIMARY KEY (`id`),
  KEY `FK_request_users` (`id_user`),
  CONSTRAINT `FK_request_users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table hasagi-dating.requests: ~3 rows (approximately)
/*!40000 ALTER TABLE `requests` DISABLE KEYS */;
REPLACE INTO `requests` (`id`, `id_user`, `min_age`, `max_age`, `max_range`, `gender`) VALUES
	(1, 1, 18, 45, 1000, 3),
	(2, 2, 18, 45, 1000, 3),
	(3, 3, 18, 45, 1000, 3);
/*!40000 ALTER TABLE `requests` ENABLE KEYS */;

-- Dumping structure for table hasagi-dating.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DOB` date DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(4) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` bit(1) DEFAULT b'0',
  `report` int(5) DEFAULT '0',
  `quyen` bit(1) DEFAULT b'0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hasagi-dating.users: ~3 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`id`, `name`, `phone`, `email`, `email_verified_at`, `password`, `DOB`, `address`, `description`, `gender`, `remember_token`, `active`, `report`, `quyen`, `created_at`, `updated_at`) VALUES
	(1, 'vũ văn dương', '0123456789', 'duong@gmail.com', '2019-10-12 22:32:37', '123', '1999-02-09', '12/13/14', NULL, 0, NULL, b'1', 0, b'1', NULL, NULL),
	(2, 'nguyễn đỗ đình sang', '114', 'sangmama@gmail.com', '2019-10-13 00:15:28', '123', '1994-10-14', '113/114 , abc xyz', NULL, 1, NULL, b'1', 3, b'0', NULL, NULL),
	(3, 'nguyễn đức minh', '113', 'minhml@gmail.com', '2019-10-13 01:05:07', '123', '2001-10-13', '11/12/13 , sdfjshga, fdsfjgsajf ,fds fjasdf', 'hasagi xin tài trợ chương trình này', 2, NULL, b'0', 0, b'0', NULL, NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
