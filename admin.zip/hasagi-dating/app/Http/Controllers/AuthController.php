<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Http\Requests;
use Validator;
use App\users;
class AuthController extends Controller
{
    public function login(Request $request)
    {
        $username = $request['username'];
        $password = $request['password'];
        if (Auth::attempt(['phone' => $username, 'password' => $password])) {
                $ds = users::all();
                foreach($ds as $ds){
                    if($ds['phone'] == $request['username']){
                        Session::put('phanquyen',$ds['quyen']);
                        if($ds['quyen'] == 0){
                        return view('admin/login',['error'=>'Bạn không có quyền truy cập trang này!']);
                        }
                        Session::put('name',$ds['name']);
                    }
                }
            return view('/admin/home',['user' => Auth::user()]);
        } else{
            $validate = Validator::make(
            $request->all(),
            [
                'username' => 'required',
                'password' => 'required|min:5|max:15|',
            ],
            [
              'username.required'=>'Tài khoản không được để trống!',
              'password.required'=>'Mật khẩu không được để trống!',
              'password.min'=>'Mật khẩu phải ít nhất 5 ký tự!',
              'password.max'=>'Mật khẩu nhiều nhất 15 ký tự!',
            ],
            [   
                'username'=>'tài khoản',
                'password'=>'mật khẩu',
            ]
        );
            return view('admin/login',['error'=>'đăng nhập thất bại'])->withErrors($validate);
        }
    }
    public function logout()
    {
        Auth::logout();
        return view('/admin/login');
    }
}
