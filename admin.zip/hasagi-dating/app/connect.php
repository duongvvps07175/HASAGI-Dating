<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class connect extends Model
{
    protected $table = 'connect';

}