@extends('admin/master')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
                <h4 class="card-id_ch">Tin Nhắn</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
						<th>ID Mess</th>
						<th>ID Kết Nối</th>
						<th>Người Người Nhắn</th>
						<th>Người Người Được Nhắn</th>
						<th>Nội Dung Nhắn</th>
						<th>Thời Gian Gửi</th>
						<th>Xóa</th>
                    </thead>
                    <tbody>
                    	@forelse($kq2 as $kq2)
	                    	@forelse($ketqua as $kq)
		                    	@if($kq->id_connect == $kq2->id)
								<tr>
									<td width="100">
										{{$kq->id_mess}}
									</td>
									<td width="100">
										{{$kq->id_connect}}
									</td>
									@forelse($kq1 as $kq4)
									@if($kq->id_connect == $kq2->id)
										@if($kq2->id_user == $kq4->id)
										<td width="100">
											{{$kq4->id}}-{{$kq4->name}}
										</td>
										@endif
									@endif
									@if($kq->id_connect == $kq2->id)
									@if($kq2->object == $kq4->id)
									<td width="100">
										{{$kq4->id}}-{{$kq4->name}}
									</td>
									@endif
									@endif
									@empty
										nothing
									@endforelse
									
									<td width="100">
										{{$kq->noidung}}
									</td>
									<td width="100">
										{{$kq->created_at}}
									</td>
									<td width="100">
										<a class="btn btn-danger btn-sm" href="/admin/delMess/{{$kq->id_mess}}"><span aria-hidden="true">&times;</span></a>
									</td>
								</tr>
								@endif
							@empty
								nothing
							@endforelse
						@empty
							không có danh sách
						@endforelse
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
@endsection

