@extends('admin/master')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
              	@forelse($ketqua as $kq)
                <h4 class="card-id_ch"> Sửa Người Dùng (ID : {{$kq->id}})</h4>
                <a href="/admin/users" class="btn btn-outline-dark btn-sm">Danh Sách Người Dùng </a>
              </div>
              <div class="card-body">
                <div class="table-responsive">
					<form method="post" action="{{ url('updateUser')}}">
						@csrf
						
						  <br>
						   <input type="hidden" class="form-lh" id="id" name="id" value="{{$kq->id}}">
						Tên Người Dùng: <input type="text" class="form-control" id="ten" name="name" value="{{$kq->name}}">
					      <br>
					    Số Điện Thoại :  <input class="form-control" type="text" id="mail" name="phone" value="{{$kq->phone}}">
					    Mật Khẩu :  <input class="form-control" type="text" id="mail" name="password" value="{{$kq->password}}">
					    Email :  <input class="form-control" type="text" id="mail" name="email" value="{{$kq->email}}" >
					    Ngày Sinh :  <input class="form-control" type="date" id="mail" name="DOB" value="{{$kq->DOB}}" >
					    Địa Chỉ :  <input class="form-control" type="text" id="mail" name="address" value="{{$kq->address}}" >
					    Giới Tính :<input class="form-control" type="text" id="mail" name="gender" value="{{$kq->gender}}" >
						Kích Hoạt:  <input class="form-control" type="text" id="mail" name="active" value="{{$kq->active}}" >
						Quyền :<input class="form-control" type="text" id="mail" name="quyen" value="{{$kq->quyen}}" >
					    Giới Thiệu :  <input class="form-control" type="text" id="mail" name="description" value="{{$kq->description}}">
					    @empty
					      Không Có Gì
					    @endforelse
					      <br>
					      <br>
					      <input type="submit" class=" btn btn-info" value="Sửa">
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection