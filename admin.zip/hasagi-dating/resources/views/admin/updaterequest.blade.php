@extends('admin/master')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
              	@forelse($ketqua as $kq)
                <h4 class="card-id_ch"> Sửa Yêu Cầu (ID : {{$kq->id}})</h4>
                <a href="/admin/users" class="btn btn-outline-dark btn-sm">Danh Sách Yêu Cầu </a>
              </div>
              <div class="card-body">
                <div class="table-responsive">
					<form method="post" action="{{ url('updateRQ')}}">
						@csrf
						
						  <br>
						   <input type="hidden" class="form-lh" id="id" name="id" value="{{$kq->id}}">
						Người Dùng: <input type="text" class="form-control" id="ten" name="id_user" value="{{$kq->id_user}}">
					     <br>
					    Tuổi Tối Thiểu :  <input class="form-control" type="text" id="mail" name="min_age" value="{{$kq->min_age}}">
					    Tuổi Tối Đa :  <input class="form-control" type="text" id="mail" name="max_age" value="{{$kq->max_age}}">
					    Khoảng Cách Tối Đa :  <input class="form-control" type="text" id="mail" name="max_range" value="{{$kq->max_range}}" >
					    Giới Tính :
					    <select class="form-control" name="gender" multiple>
					    	<option value="3">Tất Cả</option>
					    	<option value="0">Nam</option>
					    	<option value="1">Nữ</option>
					    	<option value="2">Khác</option>
					    </select>
					    @empty
					      Không Có Gì
					    @endforelse
					      <br>
					      <br>
					      <input type="submit" class=" btn btn-info" value="Sửa">
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection 