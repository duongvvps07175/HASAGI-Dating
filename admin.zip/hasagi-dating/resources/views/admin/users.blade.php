@extends('admin/master')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
                <h4 class="card-id_ch">Người Dùng</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
						<th>ID User</th>
						<th>Họ Tên</th>
						<th>Số Điện Thoại</th>
						<th>Mật Khẩu</th>
						<th>Email</th>
						<th>Địa Chỉ</th>
						<th>Giới Thiệu</th>
						<th>Giới Tính</th>
						<th>Tuổi</th>
						<th>Kích Hoạt</th>
						<th>Báo Cáo</th>
						<th>Phân quyền</th>
						<th>Sửa</th>
						<th>Xóa</th>
                    </thead>
                    <tbody>
                    @forelse($kq as $kq)
					<tr>
						<td width="100">
							{{$id_user = $kq->id}}
						</td>
						<td width="100">
							{{$kq->name}}
						</td>
						<td width="100">
							{{$kq->phone}}
						</td>
						<td width="100">
							{{$kq->password}}
						</td>
						<td width="100">
							{{$kq->email}}
						</td>
						<td width="100">
							{{$kq->address}}
						</td>
						<td width="100">
							{{$kq->description}}
						</td>
						<td width="100">
							@if($kq->gender == 0)
								Nam
							@elseif($kq->gender == 1)
								Nữ
							@else
								Khác
							@endif
						</td>
						<td width="100">
							<?php echo $dt->diffInYears($kq->DOB) ?>
						</td>
						<td width="100">
							@if($kq->active == 1)
								<span style="color:green;font-size:30px" aria-hidden="true">&#10004;</span>
							@else
								<span style="color:red;font-size:30px;font-weight: bold" aria-hidden="true">&times;</span>
							@endif
						</td>
						<td width="100">
							{{$kq->report}}
						</td>
						<td width="100">
							@if($kq->quyen == 0)
								Người Dùng
							@else
								Admin
							@endif					
						</td>
						<td width="100">
							<a class="btn btn-info btn-sm" href="/admin/updateUser/{{$kq->id}}"><i aria-hidden="true" style="font-size:16px;" class="nc-icon nc-settings"></i></a>
						</td>
						<td width="100">
							<a class="btn btn-danger btn-sm" href="/admin/deleteUser/{{$kq->id}}"><span style="font-size:20px;" aria-hidden="true">&times;</span></a>
						</td>
					</tr>
					@empty
						không có danh sách
						@endforelse
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
@endsection

