@extends('admin/master')
@section('content')
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
                <h4 class="card-id_ch">Kết Nối</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
						<th>ID Kết Nối</th>
						<th>Người Like</th>
						<th>Người Được Like</th>
						<th>Xóa</th>
                    </thead>
                    <tbody>
                    @forelse($ketqua as $kq)
					<tr>
						<td width="100">
							{{$kq->id}}
						</td>
						<td width="100">
							@forelse($kq1 as $kq2)
								@if($kq->id_user === $kq2->id)
								{{$kq2->id}}-{{$kq2->name}}
								@endif
							@empty
							nothing
							@endforelse
						</td>
						<td width="100">
							@forelse($kq1 as $kq2)
								@if($kq->object === $kq2->id)
								{{$kq2->id}}-{{$kq2->name}}
								@endif
							@empty
							nothing
							@endforelse
						</td>
						<td width="100">
							<a class="btn btn-danger btn-sm" href="/admin/delConnect/{{$kq->id}}"><span aria-hidden="true">&times;</span></a>
						</td>
					</tr>
					@empty
						không có danh sách
						@endforelse
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
@endsection

