<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="#" class="simple-text logo-mini">
          <div class="logo-image-small">
            <img src="{{ asset('')}}assets/img/logo-small.png">
          </div>
        </a>
        <a href="/admin/users" class="simple-text logo-small">
            <i style="font-size:80%;">{{Session::get('name')}}</i>
          <!-- <div class="logo-image-big">
            <img src="assets/img/logo-big.png">
          </div> -->
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="{{ Request::is('admin') ? 'active' : null }}">
            <a href="/admin/home">
              <i class="nc-icon nc-bank"></i>
              <p>Trang Chủ</p>
            </a>
          </li>
          <li class="{{ Request::is('admin/users') ? 'active' : null }}">
            <a href="/admin/users">
              <i class="nc-icon nc-circle-10"></i>
              <p>Người Dùng</p>
            </a>
          </li>
          <li class="{{ Request::is('admin/mess') ? 'active' : null }}">
            <a href="/admin/mess">
              <i class="nc-icon nc-chat-33"></i>
              <p>Tin Nhắn</p>
            </a>
          </li>
          <li class="{{ Request::is('admin/images') ? 'active' : null }}">
            <a href="/admin/images">
              <i class="nc-icon nc-image"></i>
              <p>Hình Ảnh</p>
            </a>
          </li>
          <li class="{{ Request::is('admin/likes') ? 'active' : null }}">
            <a href="/admin/likes">
              <i class="nc-icon nc-favourite-28"></i>
              <p>Lượt Like</p>
            </a>
          </li>
          <li class="{{ Request::is('admin/Addconnect') ? 'active' : null }}">
            <a href="/admin/connect">
              <i class="nc-icon nc-vector"></i>
              <p>Kết Nối</p>
            </a>
          </li>
          <li class="{{ Request::is('admin/request') ? 'active' : null }}">
            <a href="/admin/request">
              <i class="nc-icon nc-email-85"></i>
              <p>Yêu Cầu</p>
            </a>
          </li>
          <li class="active-pro">
              <a href="/admin/logout">
              <i class="nc-icon nc-button-power"></i>
              <p>Đăng Xuất</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->

