<meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('')); ?>assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="<?php echo e(asset('')); ?>assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Hasagi
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="<?php echo e(asset('')); ?>assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="<?php echo e(asset('')); ?>assets/css/paper-dashboard.css?v=2.0.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?php echo e(asset('')); ?>assets/demo/demo.css" rel="stylesheet" />
  <script type="text/javascript" src="<?php echo e(asset('')); ?>edit/ckeditor/ckeditor.js"></script>
  <script src="//cdn.ckeditor.com/4.11.4/standard/ckeditor.js"></script>
</head>
<body>
  <?php if(Auth::check()): ?>
     <?php if(Session::get('phanquyen') == 1): ?>
      <?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->yieldContent('content'); ?>
      <?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
    <div style="margin-left: 45%;margin-top:20%;">
      <b>bạn không có quyền truy cập trang web này!!</b>
      <a href="/admin"><button class="btn btn-danger sm">Đăng nhập</button></a>
    </div>
    <?php endif; ?>
  <?php else: ?>
  <div style="margin-left: 45%;margin-top:20%;">
    <b>bạn chưa đăng nhập!!</b>
    <br>
    <a href="/admin"><button class="btn btn-danger sm">Đăng nhập</button></a>
  </div>
  <?php endif; ?>
</body>
</html><?php /**PATH C:\laragon\www\hasagi-dating\resources\views/admin/master.blade.php ENDPATH**/ ?>