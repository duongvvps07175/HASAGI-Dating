<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
                <h4 class="card-id_ch">Người Dùng</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
						<th>ID User</th>
						<th>Họ Tên</th>
						<th>Số Điện Thoại</th>
						<th>Mật Khẩu</th>
						<th>Email</th>
						<th>Địa Chỉ</th>
						<th>Giới Thiệu</th>
						<th>Giới Tính</th>
						<th>Tuổi</th>
						<th>Kích Hoạt</th>
						<th>Báo Cáo</th>
						<th>Phân quyền</th>
						<th>Sửa</th>
						<th>Xóa</th>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $kq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr>
						<td width="100">
							<?php echo e($id_user = $kq->id); ?>

						</td>
						<td width="100">
							<?php echo e($kq->name); ?>

						</td>
						<td width="100">
							<?php echo e($kq->phone); ?>

						</td>
						<td width="100">
							<?php echo e($kq->password); ?>

						</td>
						<td width="100">
							<?php echo e($kq->email); ?>

						</td>
						<td width="100">
							<?php echo e($kq->address); ?>

						</td>
						<td width="100">
							<?php echo e($kq->description); ?>

						</td>
						<td width="100">
							<?php if($kq->gender == 0): ?>
								Nam
							<?php elseif($kq->gender == 1): ?>
								Nữ
							<?php else: ?>
								Khác
							<?php endif; ?>
						</td>
						<td width="100">
							<?php echo $dt->diffInYears($kq->DOB) ?>
						</td>
						<td width="100">
							<?php if($kq->active == 1): ?>
								<span style="color:green;font-size:30px" aria-hidden="true">&#10004;</span>
							<?php else: ?>
								<span style="color:red;font-size:30px;font-weight: bold" aria-hidden="true">&times;</span>
							<?php endif; ?>
						</td>
						<td width="100">
							<?php echo e($kq->report); ?>

						</td>
						<td width="100">
							<?php if($kq->quyen == 0): ?>
								Người Dùng
							<?php else: ?>
								Admin
							<?php endif; ?>					
						</td>
						<td width="100">
							<a class="btn btn-info btn-sm" href="/admin/updateUser/<?php echo e($kq->id); ?>"><i aria-hidden="true" style="font-size:16px;" class="nc-icon nc-settings"></i></a>
						</td>
						<td width="100">
							<a class="btn btn-danger btn-sm" href="/admin/deleteUser/<?php echo e($kq->id); ?>"><span style="font-size:20px;" aria-hidden="true">&times;</span></a>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						không có danh sách
						<?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hasagi-dating\resources\views//admin/users.blade.php ENDPATH**/ ?>