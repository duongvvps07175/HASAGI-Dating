<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
                <h4 class="card-id_ch">Tin Nhắn</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
						<th>ID Mess</th>
						<th>ID Kết Nối</th>
						<th>Người Người Nhắn</th>
						<th>Người Người Được Nhắn</th>
						<th>Nội Dung Nhắn</th>
						<th>Thời Gian Gửi</th>
						<th>Xóa</th>
                    </thead>
                    <tbody>
                    	<?php $__empty_1 = true; $__currentLoopData = $kq2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	                    	<?php $__empty_2 = true; $__currentLoopData = $ketqua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
		                    	<?php if($kq->id_connect == $kq2->id): ?>
								<tr>
									<td width="100">
										<?php echo e($kq->id_mess); ?>

									</td>
									<td width="100">
										<?php echo e($kq->id_connect); ?>

									</td>
									<?php $__empty_3 = true; $__currentLoopData = $kq1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
									<?php if($kq->id_connect == $kq2->id): ?>
										<?php if($kq2->id_user == $kq4->id): ?>
										<td width="100">
											<?php echo e($kq4->id); ?>-<?php echo e($kq4->name); ?>

										</td>
										<?php endif; ?>
									<?php endif; ?>
									<?php if($kq->id_connect == $kq2->id): ?>
									<?php if($kq2->object == $kq4->id): ?>
									<td width="100">
										<?php echo e($kq4->id); ?>-<?php echo e($kq4->name); ?>

									</td>
									<?php endif; ?>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
										nothing
									<?php endif; ?>
									
									<td width="100">
										<?php echo e($kq->noidung); ?>

									</td>
									<td width="100">
										<?php echo e($kq->created_at); ?>

									</td>
									<td width="100">
										<a class="btn btn-danger btn-sm" href="/admin/delMess/<?php echo e($kq->id_mess); ?>"><span aria-hidden="true">&times;</span></a>
									</td>
								</tr>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
								nothing
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							không có danh sách
						<?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hasagi-dating\resources\views//admin/mess.blade.php ENDPATH**/ ?>