<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
              	<?php $__empty_1 = true; $__currentLoopData = $ketqua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <h4 class="card-id_ch"> Sửa Yêu Cầu (ID : <?php echo e($kq->id); ?>)</h4>
                <a href="/admin/users" class="btn btn-outline-dark btn-sm">Danh Sách Yêu Cầu </a>
              </div>
              <div class="card-body">
                <div class="table-responsive">
					<form method="post" action="<?php echo e(url('updateRQ')); ?>">
						<?php echo csrf_field(); ?>
						
						  <br>
						   <input type="hidden" class="form-lh" id="id" name="id" value="<?php echo e($kq->id); ?>">
						Người Dùng: <input type="text" class="form-control" id="ten" name="id_user" value="<?php echo e($kq->id_user); ?>">
					     <br>
					    Tuổi Tối Thiểu :  <input class="form-control" type="text" id="mail" name="min_age" value="<?php echo e($kq->min_age); ?>">
					    Tuổi Tối Đa :  <input class="form-control" type="text" id="mail" name="max_age" value="<?php echo e($kq->max_age); ?>">
					    Khoảng Cách Tối Đa :  <input class="form-control" type="text" id="mail" name="max_range" value="<?php echo e($kq->max_range); ?>" >
					    Giới Tính :
					    <select class="form-control" name="gender" multiple>
					    	<option value="3">Tất Cả</option>
					    	<option value="0">Nam</option>
					    	<option value="1">Nữ</option>
					    	<option value="2">Khác</option>
					    </select>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					      Không Có Gì
					    <?php endif; ?>
					      <br>
					      <br>
					      <input type="submit" class=" btn btn-info" value="Sửa">
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hasagi-dating\resources\views//admin/updaterequest.blade.php ENDPATH**/ ?>