<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-md-12">
         	<div class="card">
              <div class="card-header">
              	<?php $__empty_1 = true; $__currentLoopData = $ketqua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <h4 class="card-id_ch"> Sửa Người Dùng (ID : <?php echo e($kq->id); ?>)</h4>
                <a href="/admin/users" class="btn btn-outline-dark btn-sm">Danh Sách Người Dùng </a>
              </div>
              <div class="card-body">
                <div class="table-responsive">
					<form method="post" action="<?php echo e(url('updateUser')); ?>">
						<?php echo csrf_field(); ?>
						
						  <br>
						   <input type="hidden" class="form-lh" id="id" name="id" value="<?php echo e($kq->id); ?>">
						Tên Người Dùng: <input type="text" class="form-control" id="ten" name="name" value="<?php echo e($kq->name); ?>">
					      <br>
					    Số Điện Thoại :  <input class="form-control" type="text" id="mail" name="phone" value="<?php echo e($kq->phone); ?>">
					    Mật Khẩu :  <input class="form-control" type="text" id="mail" name="password" value="<?php echo e($kq->password); ?>">
					    Email :  <input class="form-control" type="text" id="mail" name="email" value="<?php echo e($kq->email); ?>" >
					    Ngày Sinh :  <input class="form-control" type="date" id="mail" name="DOB" value="<?php echo e($kq->DOB); ?>" >
					    Địa Chỉ :  <input class="form-control" type="text" id="mail" name="address" value="<?php echo e($kq->address); ?>" >
					    Giới Tính :<input class="form-control" type="text" id="mail" name="gender" value="<?php echo e($kq->gender); ?>" >
						Kích Hoạt:  <input class="form-control" type="text" id="mail" name="active" value="<?php echo e($kq->active); ?>" >
						Quyền :<input class="form-control" type="text" id="mail" name="quyen" value="<?php echo e($kq->quyen); ?>" >
					    Giới Thiệu :  <input class="form-control" type="text" id="mail" name="description" value="<?php echo e($kq->description); ?>">
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					      Không Có Gì
					    <?php endif; ?>
					      <br>
					      <br>
					      <input type="submit" class=" btn btn-info" value="Sửa">
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hasagi-dating\resources\views//admin/updateuser.blade.php ENDPATH**/ ?>